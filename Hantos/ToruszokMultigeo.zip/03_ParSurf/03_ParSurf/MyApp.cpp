#include "MyApp.h"
#include "GLUtils.hpp"

#include <math.h>

CMyApp::CMyApp(void)
{
	m_vao_torusID = 0;
	m_vbo_torusID = 0;
	m_ib_torusID = 0;

	m_vao_linesID = 0;
	m_vbo_linesID = 0;
	m_ib_linesID = 0;


	m_programID = 0;
}


CMyApp::~CMyApp(void)
{
}

//
// egy parametrikus fel�let (u,v) param�ter�rt�kekhez tartoz� pontj�nak
// kisz�m�t�s�t v�gz� f�ggv�ny
//
glm::vec3	CMyApp::GetUV(float u, float v)
{
	// T�rusz parametrikus egyenlete: http://mathworld.wolfram.com/Torus.html
	// u,v param�terek 0 �s 2*pi k�z�tti �rt�kek
	// u bej�r�si ir�ny�t megford�tottuk, mert k�l�nben a h�romsz�geink ford�tva jelenn�nek meg!
	// a: a t�rusz cs�v�nek sugara
	// c: a t�rusz cs�v�nek k�z�ppontj�nak orig�t�l m�rt t�vols�ga

	// figyelj�nk:	matematik�ban sokszor a Z tengely mutat felfel�, de n�lunk az Y, teh�t a legt�bb k�plethez k�pest n�lunk
	//				az Y �s Z koordin�t�k felcser�lve szerepelnek
	u *= -2*3.1415f;
	v *= 2*3.1415f;
	float cu = cosf(u), su = sinf(u), cv = cosf(v), sv = sinf(v);
	float a = 2;
	float c = 4;

	return glm::vec3( (c + a*cv)*cu, a*sv, (c + a*cv)*su );
}

bool CMyApp::Init()
{
	// t�rl�si sz�n legyen k�kes
	glClearColor(0.125f, 0.25f, 0.5f, 1.0f);

	glEnable(GL_CULL_FACE); // kapcsoljuk be a hatrafele nezo lapok eldobasat
	glEnable(GL_DEPTH_TEST); // m�lys�gi teszt bekapcsol�sa (takar�s)
	glCullFace(GL_BACK); // GL_BACK: a kamer�t�l "elfel�" n�z� lapok, GL_FRONT: a kamera fel� n�z� lapok

	// ha szeretn�nk hogy minden dr�tv�zas legyen, szedj�k ki a
	//  glEnable(GL_CULL_FACE);
	// sort, �s adjuk ki a k�vetkez� utas�t�st (mind az el�lapokat, mind a h�tlapokat
	// dr�tv�zasan jelen�tj�k meg)
	//  glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	//
	// geometria letrehozasa
	//

	// ****************************************************
	// T�RUSZ GEOMETRI�J�NAK L�TREHOZ�SA
	// ****************************************************

	// NxM darab n�gysz�ggel k�zel�tj�k a parametrikus fel�let�nket => (N+1)x(M+1) pontban kell ki�rt�kelni
	Vertex vert_torus[(N+1)*(M+1)];
	for (int i=0; i<=N; ++i)
		for (int j=0; j<=M; ++j)
		{
			float u = i/(float)N;
			float v = j/(float)M;

			vert_torus[i + j*(N + 1)].p = GetUV(u, v);
			vert_torus[i + j*(N + 1)].c = glm::normalize(vert_torus[i + j*(N + 1)].p);
		}

	// indexpuffer adatai: NxM n�gysz�g = 2xNxM h�romsz�g = h�romsz�glista eset�n 3x2xNxM index
    GLushort indices_torus[3*2*(N)*(M)];
	for (int i = 0; i < N; ++i){
		for (int j = 0; j < M; ++j)
		{
			// minden n�gysz�gre csin�ljunk kett� h�romsz�get, amelyek a k�vetkez� 
			// (i,j) indexekn�l sz�letett (u_i, v_i) param�ter�rt�kekhez tartoz�
			// pontokat k�tik �ssze:
			//
			//		(i,j+1)
			//		  o-----o(i+1,j+1)
			//		  |\    |			a = p(u_i, v_i)
			//		  | \   |			b = p(u_{i+1}, v_i)
			//		  |  \  |			c = p(u_i, v_{i+1})
			//		  |   \ |			d = p(u_{i+1}, v_{i+1})
			//		  |	   \|
			//	(i,j) o-----o(i+1, j)
			//
			// - az (i,j)-hez tart�z� 1D-s index a VBO-ban: i+j*(N+1)
			// - az (i,j)-hez tart�z� 1D-s index az IB-ben: i*6+j*6*(N+1) 
			//		(mert minden n�gysz�gh�z 2db h�romsz�g = 6 index tartozik)
			//
			indices_torus[6 * i + j * 3 * 2 * (N)+0] = (i)+		 (j)*	 (N + 1);
			indices_torus[6 * i + j * 3 * 2 * (N)+1] = (i + 1) + (j)*	 (N + 1);
			indices_torus[6 * i + j * 3 * 2 * (N)+2] = (i)+		 (j + 1)*(N + 1);
			indices_torus[6 * i + j * 3 * 2 * (N)+3] = (i + 1) + (j)*	 (N + 1);
			indices_torus[6 * i + j * 3 * 2 * (N)+4] = (i + 1) + (j + 1)*(N + 1);
			indices_torus[6 * i + j * 3 * 2 * (N)+5] = (i)+		 (j + 1)*(N + 1);
		}
	}

	// ****************************************************
	// T�RUSZRA VONATKOZ� GEOMETRIA �TAD�SA A GPU-NAK
	// ****************************************************

	// 1 db VAO foglalasa
	glGenVertexArrays(1, &m_vao_torusID);
	// a frissen gener�lt VAO beallitasa akt�vnak
	glBindVertexArray(m_vao_torusID);
	
	// hozzunk l�tre egy �j VBO er�forr�s nevet
	glGenBuffers(1, &m_vbo_torusID); 
	glBindBuffer(GL_ARRAY_BUFFER, m_vbo_torusID); // tegy�k "akt�vv�" a l�trehozott VBO-t
	// t�lts�k fel adatokkal az akt�v VBO-t
	glBufferData( GL_ARRAY_BUFFER,	// az akt�v VBO-ba t�lts�nk adatokat
				  sizeof(vert_torus),		// ennyi b�jt nagys�gban
				  vert_torus,	// err�l a rendszermem�riabeli c�mr�l olvasva
				  GL_STATIC_DRAW);	// �gy, hogy a VBO-nkba nem tervez�nk ezut�n �rni �s minden kirajzol�skor felhasnz�ljuk a benne l�v� adatokat
	

	// VAO-ban jegyezz�k fel, hogy a VBO-ban az els� 3 float sizeof(Vertex)-enk�nt lesz az els� attrib�tum (poz�ci�)
	glEnableVertexAttribArray(0); // ez lesz majd a poz�ci�
	glVertexAttribPointer(
		0,				// a VB-ben tal�lhat� adatok k�z�l a 0. "index�" attrib�tumait �ll�tjuk be
		3,				// komponens szam
		GL_FLOAT,		// adatok tipusa
		GL_FALSE,		// normalizalt legyen-e
		sizeof(Vertex),	// stride (0=egymas utan)
		0				// a 0. index� attrib�tum hol kezd�dik a sizeof(Vertex)-nyi ter�leten bel�l
	); 

	// a m�sodik attrib�tumhoz pedig a VBO-ban sizeof(Vertex) ugr�s ut�n sizeof(glm::vec3)-nyit menve �jabb 3 float adatot tal�lunk (sz�n)
	glEnableVertexAttribArray(1); // ez lesz majd a sz�n
	glVertexAttribPointer(
		1,
		3, 
		GL_FLOAT,
		GL_FALSE,
		sizeof(Vertex),
		(void*)(sizeof(glm::vec3)) );

	// index puffer l�trehoz�sa
	glGenBuffers(1, &m_ib_torusID);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_ib_torusID);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices_torus), indices_torus, GL_STATIC_DRAW);

	glBindVertexArray(0); // felt�lt�tt�k a VAO-t, kapcsoljuk le
	glBindBuffer(GL_ARRAY_BUFFER, 0); // felt�lt�tt�k a VBO-t is, ezt is vegy�k le
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0); // felt�lt�tt�k a VBO-t is, ezt is vegy�k le

	// ****************************************************
	// VONALAK GEOMETRI�J�NAK L�TREHOZ�SA
	// ****************************************************

	// rakjuk �ssze a f�tengelyeket szimboliz�l� vonalakat!
	Vertex vert_lines[6];

	// egy vertex k�z�pre, egy a (10,0,0) poz�ci�ra
	// mindkett� piros sz�nnel (ez lesz a piros vonal, ami az x tengely�nket mutatja)
	vert_lines[0].p = glm::vec3(0, 0, 0);
	vert_lines[0].c = glm::vec3(1, 0, 0);
	vert_lines[1].p = glm::vec3(10, 0, 0);
	vert_lines[1].c = glm::vec3(1, 0, 0);
	// egy vertex k�z�pre, egy a (0,10,0) poz�ci�ra
	// mindkett� z�ld sz�nnel (ez lesz a z�ld vonal, ami az y tengely�nket mutatja)
	vert_lines[2].p = glm::vec3(0, 0, 0);
	vert_lines[2].c = glm::vec3(0, 1, 0);
	vert_lines[3].p = glm::vec3(0, 10, 0);
	vert_lines[3].c = glm::vec3(0, 1, 0);
	// egy vertex k�z�pre, egy a (0,0,10) poz�ci�ra
	// mindkett� k�k sz�nnel (ez lesz a k�k vonal, ami a z tengely�nket mutatja)
	vert_lines[4].p = glm::vec3(0, 0, 0);
	vert_lines[4].c = glm::vec3(0, 0, 1);
	vert_lines[5].p = glm::vec3(0, 0, 10);
	vert_lines[5].c = glm::vec3(0, 0, 1);
	
	GLushort indices_lines[6];
	// mivel a kirajzol�skor GL_LINES-t haszn�lunk,
	// p�ros�val fogjuk �sszek�tni a vonalakat,
	// �s a vert_lines t�mbben eleve �gy hoztuk l�tre �ket,
	// ez�rt az indices t�mb egyszer�en a vert_lines szerint tartalmazza a sorsz�mokat
	indices_lines[0] = 0; // ez a piros vertex az orig�ban
	indices_lines[1] = 1; // ez a piros vertex az x tengelyen
	indices_lines[2] = 2; // ez a z�ld vertex az orig�ban
	indices_lines[3] = 3; // ez a z�ld vertex az y tengelyen
	indices_lines[4] = 4; // ez a k�k vertex az orig�ban
	indices_lines[5] = 5; // ez a k�k vertex a z tengelyen

	// ****************************************************
	// VONALAKRA VONATKOZ� GEOMETRIA �TAD�SA A GPU-NAK
	// ****************************************************

	// VAO l�trehoz�sa
	glGenVertexArrays(1, &m_vao_linesID);
	glBindVertexArray(m_vao_linesID);

	// VBO l�trehoz�sa �s felt�lt�se a vert_lines t�mbbel
	glGenBuffers(1, &m_vbo_linesID);
	glBindBuffer(GL_ARRAY_BUFFER, m_vbo_linesID);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vert_lines), vert_lines, GL_STATIC_DRAW);

	// A VAO-t ugyan�gy t�ltj�k fel, mert a vertexeink attrib�tumai ugyanazok, mint a t�rusz eset�n
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), 0);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)(sizeof(glm::vec3)));

	// az index puffer l�trehoz�sa �s felt�lt�se az indices_lines t�mbbel
	glGenBuffers(1, &m_ib_linesID);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_ib_linesID);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices_lines), indices_lines, GL_STATIC_DRAW);

	glBindVertexArray(0); // felt�lt�tt�k a VAO-t, kapcsoljuk le
	glBindBuffer(GL_ARRAY_BUFFER, 0); // felt�lt�tt�k a VBO-t is, ezt is vegy�k le
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0); // felt�lt�tt�k a VBO-t is, ezt is vegy�k le

	//
	// shaderek bet�lt�se
	//
	GLuint vs_ID = loadShader(GL_VERTEX_SHADER,		"myVert.vert");
	GLuint fs_ID = loadShader(GL_FRAGMENT_SHADER,	"myFrag.frag");

	// a shadereket t�rol� program l�trehoz�sa
	m_programID = glCreateProgram();

	// adjuk hozz� a programhoz a shadereket
	glAttachShader(m_programID, vs_ID);
	glAttachShader(m_programID, fs_ID);

	// VAO-beli attrib�tumok hozz�rendel�se a shader v�ltoz�khoz
	// FONTOS: linkel�s el�tt kell ezt megtenni!
	glBindAttribLocation(	m_programID,	// shader azonos�t�ja, amib�l egy v�ltoz�hoz szeretn�nk hozz�rendel�st csin�lni
							0,				// a VAO-beli azonos�t� index
							"vs_in_pos");	// a shader-beli v�ltoz�n�v
	glBindAttribLocation( m_programID, 1, "vs_in_col");

	// illessz�k �ssze a shadereket (kimen�-bemen� v�ltoz�k �sszerendel�se stb.)
	glLinkProgram(m_programID);

	// linkeles ellenorzese
	GLint infoLogLength = 0, result = 0;

	glGetProgramiv(m_programID, GL_LINK_STATUS, &result);
	glGetProgramiv(m_programID, GL_INFO_LOG_LENGTH, &infoLogLength);
	if ( GL_FALSE == result )
	{
		std::vector<char> ProgramErrorMessage( infoLogLength );
		glGetProgramInfoLog(m_programID, infoLogLength, NULL, &ProgramErrorMessage[0]);
		fprintf(stdout, "%s\n", &ProgramErrorMessage[0]);
		
		char* aSzoveg = new char[ProgramErrorMessage.size()];
		memcpy( aSzoveg, &ProgramErrorMessage[0], ProgramErrorMessage.size());

		std::cout << "[app.Init()] S�der Huba panasza: " << aSzoveg << std::endl;

		delete aSzoveg;
	}

	// mar nincs ezekre szukseg
	glDeleteShader( vs_ID );
	glDeleteShader( fs_ID );

	//
	// egy�b inicializ�l�s
	//

	// vet�t�si m�trix l�trehoz�sa
	m_matProj = glm::perspective( 45.0f, 640/480.0f, 1.0f, 1000.0f );

	// shader-beli transzform�ci�s m�trixok c�m�nek lek�rdez�se
	m_loc_mvp = glGetUniformLocation( m_programID, "MVP");

	return true;
}

void CMyApp::Clean()
{
	glDeleteBuffers(1, &m_vbo_torusID);
	glDeleteBuffers(1, &m_ib_torusID);
	glDeleteVertexArrays(1, &m_vao_torusID);

	glDeleteBuffers(1, &m_vbo_linesID);
	glDeleteBuffers(1, &m_ib_linesID);
	glDeleteVertexArrays(1, &m_vao_linesID);

	glDeleteProgram( m_programID );
}

void CMyApp::Update()
{
	// n�zeti transzform�ci� be�ll�t�sa
	m_matView = glm::lookAt(glm::vec3( 15*cosf(cam_rot),  cam_y,  15*sinf(cam_rot)),		// honnan n�zz�k a sz�nteret
							glm::vec3( 0,  0,  0),		// a sz�nt�r melyik pontj�t n�zz�k
							glm::vec3( 0,  1,  0));		// felfel� mutat� ir�ny a vil�gban
}


void CMyApp::Render()
{
	// t�r�lj�k a frampuffert (GL_COLOR_BUFFER_BIT) �s a m�lys�gi Z puffert (GL_DEPTH_BUFFER_BIT)
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// shader bekapcsolasa
	glUseProgram( m_programID );

	// shader parameterek be�ll�t�sa
	/*

	GLM transzform�ci�s m�trixokra p�ld�k:
		glm::rotate<float>( sz�g, tengely_x, tengely_y, tengely_z) <- tengely_{xyz} k�r�li elforgat�s
		glm::translate<float>( eltol_x, eltol_y, eltol_z) <- eltol�s
		glm::scale<float>( s_x, s_y, s_z ) <- l�pt�kez�s

	*/
	m_matWorld = glm::mat4(1.0f);

	glm::mat4 mvp = m_matProj * m_matView * m_matWorld;

	// majd k�ldj�k �t a megfelel� m�trixot!
	glUniformMatrix4fv( m_loc_mvp,// erre a helyre t�lts�nk �t adatot
						1,			// egy darab m�trixot
						GL_FALSE,	// NEM transzpon�lva
						&(mvp[0][0]) ); // innen olvasva a 16 x sizeof(float)-nyi adatot

	// kapcsoljuk be a t�rusz VAO-t (a VBO �s az IB j�n vele egy�tt)
	glBindVertexArray(m_vao_torusID);
	// NAGY T�RUSZ KIRAJZOL�SA: k�l�n�ll� h�romsz�gek
	glDrawElements(	GL_TRIANGLES,		// primit�v t�pus
					3*2*(N)*(M),		// hany csucspontot hasznalunk a kirajzolashoz
					GL_UNSIGNED_SHORT,	// indexek tipusa
					0);					// indexek cime
	glBindVertexArray(0); // kikapcsoljuk a t�rusz VAO-t


	// VONALAK KIRAJZOL�SA: k�l�n�ll� vonalak
	glBindVertexArray(m_vao_linesID); // vonalak VAO-ja be
	glDrawElements(GL_LINES, 6,	GL_UNSIGNED_SHORT, 0); // vonalak rajzol�sa
	glBindVertexArray(0); // vonalak VAO-ja ki

	// KIS T�RUSZOK KIRAJZOL�SA
	for (int i = 0; i < 6; ++i){
		// �j vil�gtranszform�ci�t sz�molunk, elemi transzform�ci�k szorzat�b�l

		// step 1: a t�ruszt 1/8-ad�ra zsugor�tjuk
		glm::mat4 S = glm::scale<float>(1/8.0f, 1/8.0f, 1/8.0f);
		// step 2: �l�re �ll�tjuk
		glm::mat4 R1 = glm::rotate<float>(90, 1, 0, 0);
		// step 3: forgatjuk a saj�t tengelye ment�n (helyben forg�s: 5mp alatt tesz meg egy k�rt)
		glm::mat4 R2 = glm::rotate<float>(SDL_GetTicks() / 5000.0f*360, 0, 0, 1);
		// step 4: eltoljuk a nagy t�rusz �l�re
		// az eredeti t�ruszn�l c = 4, a = 2
		// z = 4 eltol�ssal kivissz�k a t�rusz �ves vonala al�,
		// y �rt�k pedig a + (c+a)/8, mivel a kis t�rusz a nagynak m�retben a nyolcada
		glm::mat4 T = glm::translate<float>(0, 2 + (4+2)/8.0f, 4);
		// ciklus mag szerint sz�tsz�rjuk �ket: y tengely k�r�li forgat�s, t�ruszonk�nt 60 fok az elt�r�s
		glm::mat4 R3 = glm::rotate<float>(i*360.0f/6, 0, 1, 0);
		// elkezdj�k k�rbeforgatni �ket az y tengely ment�n (10 mp alatt tesz meg egy k�rt)
		glm::mat4 R4 = glm::rotate<float>(SDL_GetTicks() / -10000.0f*360, 0, 1, 0);

		// ne felejts�k el, hogy a szorz�sok sorrendje ford�tott a logikai sorrendhez k�pest!
		// az �j hat�st kelt� m�trixokat balr�l szorozzuk
		switch (trafo_num){
			case 1: m_matWorld =			   S;	break;
			case 2: m_matWorld =			R1*S;	break;
			case 3: m_matWorld =		 R2*R1*S;	break;
			case 4: m_matWorld =	   T*R2*R1*S;	break;
			case 5: m_matWorld =	R3*T*R2*R1*S;	break;
			case 6: m_matWorld = R4*R3*T*R2*R1*S;	break;
		}

		// mivel megv�ltozott a vil�gtranszform�ci�, �jra kell sz�molnunk a k�z�s transzform�c�s m�trixot...
		mvp = m_matProj * m_matView * m_matWorld;
		// ...�s azt �tadnunk a shadernek
		glUniformMatrix4fv(m_loc_mvp, 1, GL_FALSE, &(mvp[0][0]));
		// most m�r rajzolhatunk egy t�ruszt az �j transzform�ci�kkal
		glBindVertexArray(m_vao_torusID);
		glDrawElements(GL_TRIANGLES, 3 * 2 * (N)*(M), GL_UNSIGNED_SHORT, 0);
		glBindVertexArray(0);

		// EXTRA!
		// vajon mi t�rt�nik, ha a f�tengelyeket jelk�pez� vonalak rajzol�si utas�t�s�t itt is kiadjuk?
		// pr�b�ljuk meg el�re megtippelni, mit fogunk l�tni!
		/*  glBindVertexArray(m_vao_linesID);
		    glDrawElements(GL_LINES, 6, GL_UNSIGNED_SHORT, 0);
		    glBindVertexArray(0);
		*/
	}

	// shader kikapcsolasa
	glUseProgram( 0 );
}

void CMyApp::KeyboardDown(SDL_KeyboardEvent& key)
{
	switch (key.keysym.sym){
	case SDLK_LEFT:
		cam_rot -= 2 * 3.14152f / 60; // a teljes k�r 60-ad r�sz�vel forgatunk (azaz 6 fokkal)
		break;
	case SDLK_RIGHT:
		cam_rot += 2 * 3.14152f / 60;
		break;
	case SDLK_UP:
		cam_y += 1;
		break;
	case SDLK_DOWN:
		cam_y -= 1;
		break;
	case SDLK_1:
		trafo_num = 1;
		break;
	case SDLK_2:
		trafo_num = 2;
		break;
	case SDLK_3:
		trafo_num = 3;
		break;
	case SDLK_4:
		trafo_num = 4;
		break;
	case SDLK_5:
		trafo_num = 5;
		break;
	case SDLK_6:
		trafo_num = 6;
		break;
	}

}

void CMyApp::KeyboardUp(SDL_KeyboardEvent& key)
{
}

void CMyApp::MouseMove(SDL_MouseMotionEvent& mouse)
{

}

void CMyApp::MouseDown(SDL_MouseButtonEvent& mouse)
{
}

void CMyApp::MouseUp(SDL_MouseButtonEvent& mouse)
{
}

void CMyApp::MouseWheel(SDL_MouseWheelEvent& wheel)
{
}

// a k�t param�terbe az �j ablakm�ret sz�less�ge (_w) �s magass�ga (_h) tal�lhat�
void CMyApp::Resize(int _w, int _h)
{
	glViewport(0, 0, _w, _h);

	m_matProj = glm::perspective(  45.0f,		// 90 fokos nyilasszog
									_w/(float)_h,	// ablakmereteknek megfelelo nezeti arany
									0.01f,			// kozeli vagosik
									100.0f);		// tavoli vagosik
}