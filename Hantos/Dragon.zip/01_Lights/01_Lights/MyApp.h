#pragma once

// GLEW
#include <GL/glew.h>

// SDL
#include <SDL.h>
#include <SDL_opengl.h>

// GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform2.hpp>

#include "ObjParser_OGL3.h"

class CMyApp
{
public:
	CMyApp(void);
	~CMyApp(void);

	bool Init();
	void Clean();

	void Update();
	void Render();

	void KeyboardDown(SDL_KeyboardEvent&);
	void KeyboardUp(SDL_KeyboardEvent&);
	void MouseMove(SDL_MouseMotionEvent&);
	void MouseDown(SDL_MouseButtonEvent&);
	void MouseUp(SDL_MouseButtonEvent&);
	void MouseWheel(SDL_MouseWheelEvent&);
	void Resize(int, int);
protected:
	// private functions
	GLuint GenTexture();
	glm::vec3 ToDescartes(float u, float v);

	// shader related variables
	GLuint m_programID; // shaderek program ID

	// transformation matrices
	glm::mat4 m_matView;
	glm::mat4 m_matProj;

	// IDs of shader variables
	GLuint	m_loc_world;
	GLuint	m_loc_worldIT;
	GLuint	m_loc_mvp;
	GLuint	m_loc_texture;

	// OpenGL resource identifiers
	GLuint m_vaoID; // vertex array object resource name
	GLuint m_vboID; // vertex buffer object resource name
	GLuint m_ibID;  // index buffer object resource name
	GLuint m_groundTextureID; // text�ra resource name
	GLuint m_dragonTextureID; // text�ra resource name

	// data to be stored at each vertex
	struct Vertex
	{
		glm::vec3 p;	// vertex position
		glm::vec3 n;	// vertex normal
		glm::vec2 t;	// texture coordinates
	};

	Mesh *dragonMesh;

	// Kamera inicializ�l�s
	glm::vec3 eye = glm::vec3(0, 10, 10); // kamera poz�ci�
	glm::vec3 up = glm::vec3(0, 1, 0); // felfele ir�ny
	float u = 5, v = 2;
	glm::vec3 fw = ToDescartes(u,v); // milyen ir�nyba n�z�nk (v�zszintes �s f�gg�leges sz�gb�l sz�molva)
	glm::vec3 at = eye + fw; // melyik pontot is n�zi a kamer�nk

	bool is_left_pressed = false; // nyomva tartjuk-e a bal eg�rgombot

	// interakci�: milyen megvil�g�t�si komponenseket szeretn�nk
	bool is_ambient = true;
	bool is_diffuse = true;
	bool is_specular = true;
	int siPower = 16; // a spekul�ris f�ny intezit�c�n�l szerepl� hatv�nykitev�
};

