#pragma once

// GLEW
#include <GL/glew.h>

// SDL
#include <SDL.h>
#include <SDL_opengl.h>

// GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform2.hpp>

#include "gCamera.h"
#include "gShaderProgram.h"
#include "gVertexBuffer.h"
#include "Mesh_OGL3.h"

class CMyApp
{
public:
	CMyApp(void);
	~CMyApp(void);

	bool Init();
	void Clean();

	void Update();
	void Render();

	void KeyboardDown(SDL_KeyboardEvent&);
	void KeyboardUp(SDL_KeyboardEvent&);
	void MouseMove(SDL_MouseMotionEvent&);
	void MouseDown(SDL_MouseButtonEvent&);
	void MouseUp(SDL_MouseButtonEvent&);
	void MouseWheel(SDL_MouseWheelEvent&);
	void Resize(int, int);

	// a rajzol� met�dusaink: param�ter a vil�gtranszform�ci�
	void DrawGround(glm::mat4 &matWorld);
	void DrawSuzanne(glm::mat4 &matWorld);
	// hengerb�l t�bbet is rajzolunk, ez�rt a param�ter a diff�z sz�n is, valamint hogy haszn�ljunk-e text�r�t
	void DrawCylinder(glm::mat4 &matWorld, glm::vec4 &color, bool is_textured);

protected:
	// bels� elj�r�sok
	GLuint GenTexture();
	float TransformSine(float period, float from, float to);

	// OpenGL-es dolgok
	GLuint m_texture_groundID; // text�ra er�forr�s azonos�t�
	GLuint m_texture_hiltID; // text�ra er�forr�s azonos�t�

	glm::vec3 eye = glm::vec3(20, 20, 20);
	glm::vec3 at  = glm::vec3(0, 10, 0);
	glm::vec3 up  = glm::vec3(0, 1, 0);

	// a kamer�t tudjuk inicializ�lni
	gCamera			m_camera = gCamera(
								 glm::vec3(15, 20, 15), // eye
								 glm::vec3(0, 10, 0), // at
								 glm::vec3(0, 1, 0) // up
							   );
	gShaderProgram	m_program;

	gVertexBuffer	m_vb_ground;
	gVertexBuffer	m_vb_cylinder;
	gVertexBuffer	m_vb_cylinder_bottom;
	gVertexBuffer	m_vb_cylinder_top;
	
	int side_num = 50; // a k�r�vet alkot� vertexek sz�ma

	// a f�nykard poz�ci�ja interakt�van v�ltoztathat�
	float saber_x = 0;
	float saber_y = 0;
	float saber_z = 0;

	Mesh *m_mesh; // Suzanne
};

