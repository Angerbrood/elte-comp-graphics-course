#include "MyApp.h"
#include "GLUtils.hpp"

#include <GL/GLU.h>
#include <math.h>

#include "ObjParser_OGL3.h"

const float f_PI = 3.14512f;

CMyApp::CMyApp(void)
{
	m_texture_groundID = 0;
	m_texture_hiltID = 0;
	m_mesh = 0;
}

// olyan �rt�kkel t�r vissza, ami period szerint cikliz�l from-t�l to-ig
float CMyApp::TransformSine(float period, float from, float to){
	float t = sinf(period); // t �rt�ke megy -1-t�l 1-ig, 'period'-onk�nt
	t = (t + 1) / 2.0f;	// t �rt�ke megy 0-t�l 1-ig
	t = t*(to - from);	// t �rt�ke megy 0-t�l (to-from)-ig
	t = t + from;		// t �rt�ke megy from-t�l to-ig
	return t;
}

CMyApp::~CMyApp(void)
{
}

bool CMyApp::Init()
{
	// t�rl�si sz�n legyen k�kes
	glClearColor(0.125f, 0.25f, 0.5f, 1.0f);

	glEnable(GL_CULL_FACE);		// kapcsoljuk be a hatrafele nezo lapok eldobasat
	glEnable(GL_DEPTH_TEST);	// m�lys�gi teszt bekapcsol�sa (takar�s)

	//
	// geometria letrehozasa
	//

	// **************************
	// TALAJ
	// **************************

	m_vb_ground.AddAttribute(0, 3);
	m_vb_ground.AddAttribute(1, 3);
	m_vb_ground.AddAttribute(2, 2);
	
	m_vb_ground.AddData(0, -10, 0, -10);
	m_vb_ground.AddData(0, 10, 0, -10);
	m_vb_ground.AddData(0, -10, 0, 10);
	m_vb_ground.AddData(0, 10, 0, 10);

	m_vb_ground.AddData(1, 0, 1, 0);
	m_vb_ground.AddData(1, 0, 1, 0);
	m_vb_ground.AddData(1, 0, 1, 0);
	m_vb_ground.AddData(1, 0, 1, 0);

	m_vb_ground.AddData(2, 0, 0);
	m_vb_ground.AddData(2, 1, 0);
	m_vb_ground.AddData(2, 0, 1);
	m_vb_ground.AddData(2, 1, 1);

	m_vb_ground.AddIndex(1, 0, 2);
	m_vb_ground.AddIndex(1, 2, 3);

	m_vb_ground.InitBuffers();

	// **************************
	// HENGER PAL�ST
	// **************************

	// a henger egy XZ s�kon fekv�, orig� k�z�ppont�, egys�g sugar�, egys�g magas hengerpal�st lesz

	m_vb_cylinder.AddAttribute(0, 3);
	m_vb_cylinder.AddAttribute(1, 3);
	m_vb_cylinder.AddAttribute(2, 2);

	// a ciklusmagban k�t vertexet defini�lunk: egyet rakunk alulra, egyet fel�lre
	// a k�r�ven side_num+1 vertexet rakunk le (az els�t �s az utols�t ugyanoda)
	// �gy �sszesen 2*(side_num+1) vertex�nk lesz
	for (int i = 0; i <= side_num; ++i){
		float x = cosf(i * 2 * f_PI / side_num);
		float z = sinf(i * 2 * f_PI / side_num);
		// poz�ci�k: -0.5 �s +0.5 magasan lerakunk egym�s al� k�t vertexet
		m_vb_cylinder.AddData(0, x, -0.5, z);
		m_vb_cylinder.AddData(0, x, 0.5, z);
		// egy XZ s�kon �ll� hengerpal�st eset�ben a norm�lvektor egyenesen �ll (Y) �s kifel� mutat (XZ)
		// hengerpal�stn�l az als� �s a fels� vertex eset�ben persze ugyanaz a norm�lvektor
		m_vb_cylinder.AddData(1, x, 0, z);
		m_vb_cylinder.AddData(1, x, 0, z);
		// text�rakoordin�t�k: a text�ra alj�t illetve tetej�t j�rjuk be,
		// �gy a text�r�t k�rbeh�zzuk a teljes hengerpal�ston
		m_vb_cylinder.AddData(2, (float)i / side_num, 0);
		m_vb_cylinder.AddData(2, (float)i / side_num, 1);
		// kirajzol�sn�l majd TRIANGLE_STRIP-et haszn�lunk, �gy igaz�b�l az indexek
		// �gy j�nnek, ahogy maguk a vertexek: 0, 1, 2, 3, 4, 5, 6, ..., 2*(side_num+1)
		m_vb_cylinder.AddIndex(2 * i);
		m_vb_cylinder.AddIndex(2 * i + 1);
	}
	m_vb_cylinder.InitBuffers();

	// **************************
	// A HENGER ALS� LAPJA
	// **************************

	// egy egyszer� k�rlap, a norm�lvektorok minden esetben lefel� �llnak
	// kirajzol�sn�l TRIANGLE_FAN-t haszn�lunk, �gy az indexek itt a vertexek defini�lt sorrendj�t
	// adj�k meg: 0, 1, 2, 3, 4, ..., side_num+2

	m_vb_cylinder_bottom.AddAttribute(0, 3);
	m_vb_cylinder_bottom.AddAttribute(1, 3);
	m_vb_cylinder_bottom.AddAttribute(2, 2);
	
	// egy vertexet rakunk k�z�pre
	m_vb_cylinder_bottom.AddData(0, 0, -0.5, 0);
	m_vb_cylinder_bottom.AddData(1, 0, -1, 0);
	m_vb_cylinder_bottom.AddData(2, 0.5, 0.5);
	m_vb_cylinder_bottom.AddIndex(0); // 0. vertex

	// a k�r�ven side_num+1 vertexet rakunk le (az els�t �s az utols�t ugyanoda)
	// �gy �sszesen (a k�z�ps� vertex-szel egy�tt) side_num+2 vertex�nk lesz
	for (int i = 0; i <= side_num; ++i){
		float x = cosf(i * 2 * f_PI / side_num);
		float z = sinf(i * 2 * f_PI / side_num);
		// poz�ci�
		m_vb_cylinder_bottom.AddData(0, x, -0.5, z);
		// a norm�lvektor lefel� n�z
		m_vb_cylinder_bottom.AddData(1, 0, -1, 0);
		// a text�ra k�zep�b�l kiv�gunk egy 0.5 sugar�, (0.5, 0.5) k�z�ppont� k�rlapot
		m_vb_cylinder_bottom.AddData(2, 0.5*x + 0.5, 0.5*z + 0.5);
		m_vb_cylinder_bottom.AddIndex(i + 1);
	}
	m_vb_cylinder_bottom.InitBuffers();

	// **************************
	// A HENGER FELS� LAPJA
	// **************************

	// ugyanaz mint az als� lap, csak a norm�lvektorok felfel� �llnak,
	// �s a k�r�ven m�s ir�nyba rakjuk le a vertexeket, a h�romsz�gek a k�r�lj�r�si ir�nya miatt

	m_vb_cylinder_top.AddAttribute(0, 3);
	m_vb_cylinder_top.AddAttribute(1, 3);
	m_vb_cylinder_top.AddAttribute(2, 2);

	m_vb_cylinder_top.AddData(0, 0, 0.5, 0);
	m_vb_cylinder_top.AddData(1, 0, 1, 0);
	m_vb_cylinder_top.AddData(2, 0.5, 0.5);
	m_vb_cylinder_top.AddIndex(0);

	for (int i = 0; i <= side_num; ++i){
		float x = cosf(-i * 2 * M_PI / side_num);
		float z = sinf(-i * 2 * M_PI / side_num);
		m_vb_cylinder_top.AddData(0, x, 0.5, z);
		m_vb_cylinder_top.AddData(1, 0, 1, 0);
		m_vb_cylinder_top.AddData(2, 0.5*x + 0.5, 0.5*z + 0.5);
		m_vb_cylinder_top.AddIndex(i + 1);
	}
	m_vb_cylinder_top.InitBuffers();

	//
	// shaderek bet�lt�se
	//
	m_program.AttachShader(GL_VERTEX_SHADER, "dirLight.vert");
	m_program.AttachShader(GL_FRAGMENT_SHADER, "dirLight.frag");

	m_program.BindAttribLoc(0, "vs_in_pos");
	m_program.BindAttribLoc(1, "vs_in_normal");
	m_program.BindAttribLoc(2, "vs_in_tex0");

	if ( !m_program.LinkProgram() )
	{
		return false;
	}

	//
	// egy�b inicializ�l�s
	//

	m_camera.SetProj(45.0f, 640.0f/480.0f, 0.01f, 1000.0f);

	// text�ra bet�lt�se
	m_texture_groundID = TextureFromFile("texture.png");
	m_texture_hiltID = TextureFromFile("hilt.png");

	// mesh bet�lt�s
	m_mesh = ObjParser::parse("suzanne.obj");
	m_mesh->initBuffers();

	return true;
}

void CMyApp::Clean()
{
	glDeleteTextures(1, &m_texture_groundID);
	glDeleteTextures(1, &m_texture_hiltID);

	m_program.Clean();
}

void CMyApp::Update()
{
	static Uint32 last_time = SDL_GetTicks();
	float delta_time = (SDL_GetTicks() - last_time)/1000.0f;

	m_camera.Update(delta_time);

	last_time = SDL_GetTicks();
}

// Szuanne kirajzol�sa
void CMyApp::DrawSuzanne(glm::mat4 &matWorld){

	glm::mat4 matWorldIT = glm::transpose(glm::inverse(matWorld));
	glm::mat4 mvp = m_camera.GetViewProj() *matWorld;

	m_program.SetUniform("world", matWorld);
	m_program.SetUniform("worldIT", matWorldIT);
	m_program.SetUniform("MVP", mvp);
	m_program.SetUniform("eye_pos", m_camera.GetEye());
	
	// Suzanne ambiensben feh�r, diff�zban v�r�ses, spekul�risban z�ldes
	m_program.SetUniform("Ka", 1, 1, 1, 1);
	m_program.SetUniform("Kd", 0.75f, 0.25f, 0.125f, 1);
	m_program.SetUniform("Ks", 0.4f, 1, 0.4f, 1);

	m_program.SetUniform("is_textured", true); // mindig text�r�zunk
	m_program.SetTexture("texImage", 0, m_texture_groundID);

	m_mesh->draw();
}

// talaj/falak kirajzol�sa
void CMyApp::DrawGround(glm::mat4 &matWorld){

	glm::mat4 matWorldIT = glm::transpose(glm::inverse(matWorld));
	glm::mat4 mvp = m_camera.GetViewProj() *matWorld;

	m_program.SetUniform("world", matWorld);
	m_program.SetUniform("worldIT", matWorldIT);
	m_program.SetUniform("MVP", mvp);
	m_program.SetUniform("eye_pos", m_camera.GetEye());

	m_program.SetUniform("is_textured", true); // mindig text�r�zunk
	m_program.SetTexture("texImage", 0, m_texture_groundID);

	// A talaj �s a falak minden sz�nkomponensben feh�rek
	m_program.SetUniform("Ka", 1, 1, 1, 1);
	m_program.SetUniform("Kd", 1, 1, 1, 1);
	m_program.SetUniform("Ks", 1, 1, 1, 1);

	m_vb_ground.On();
	m_vb_ground.DrawIndexed(GL_TRIANGLES, 0, 6, 0);
	m_vb_ground.Off();
	
}

// henger kirajzol�sa
// egy henger kirajzol�s�hoz a param�terek: vil�gtranszform�ci�, diff�z sz�n, legyen-e text�r�zva
void CMyApp::DrawCylinder(glm::mat4 &matWorld, glm::vec4 &color, bool is_textured){
	m_program.On();
	glm::mat4 matWorldIT = glm::transpose(glm::inverse(matWorld));
	glm::mat4 mvp = m_camera.GetViewProj() *matWorld;

	m_program.SetUniform("world", matWorld);
	m_program.SetUniform("worldIT", matWorldIT);
	m_program.SetUniform("MVP", mvp);
	m_program.SetUniform("eye_pos", m_camera.GetEye());

	m_program.SetUniform("is_textured", is_textured);
	m_program.SetTexture("texImage", 0, m_texture_hiltID);

	// a henger ambiens �s spekul�ris sz�ne feh�r, a diff�z f�nye param�terb�l j�n
	// szint�n param�terb�l j�n az �tl�tszatlans�g
	m_program.SetUniform("Ka", 1, 1, 1, color.a);
	m_program.SetUniform("Kd", color.x, color.y, color.z, color.a);
	m_program.SetUniform("Ks", 1, 1, 1, color.a);

	// hengerpal�st: 2*(side_num+1) darab vertex
	m_vb_cylinder.On();
	m_vb_cylinder.DrawIndexed(GL_TRIANGLE_STRIP, 0, 2 * (side_num + 1), 0);
	m_vb_cylinder.Off();
	// als� lap: side_num+2 darab vertex
	m_vb_cylinder_bottom.On();
	m_vb_cylinder_bottom.DrawIndexed(GL_TRIANGLE_FAN, 0, side_num + 2, 0);
	m_vb_cylinder_bottom.Off();
	// fels� lap: side_num+2 darab vertex
	m_vb_cylinder_top.On();
	m_vb_cylinder_top.DrawIndexed(GL_TRIANGLE_FAN, 0, side_num + 2, 0);
	m_vb_cylinder_top.Off();

}

void CMyApp::Render()
{
	// t�r�lj�k a frampuffert (GL_COLOR_BUFFER_BIT) �s a m�lys�gi Z puffert (GL_DEPTH_BUFFER_BIT)
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	
	m_program.On();

	// ************************
	// TALAJ �S FALAK
	// ************************

	// a talajt h�rom p�ld�nyban rajzoljuk ki, h�rom k�l�nb�z� vil�gtranszform�ci�val
	// a vil�gtranszform�ci�t param�ter�l adjuk oda a f�ggv�nynek
	
	// talaj
	glm::mat4 w = glm::mat4(1.0f);
	DrawGround(w);
	// h�ts� fal: x tengely k�r�l elforgatva, eltolva a hely�re
	w = glm::translate<float>(0, 10, -10) * glm::rotate<float>(90, 1, 0, 0);
	DrawGround(w);
	// oldals� fal: z tengely k�r�l elforgatva, eltolva a hely�re
	w = glm::translate<float>(-10, 10, 0) * glm::rotate<float>(-90, 0, 0, 1);
	DrawGround(w);

	// Suzanne: k�tszeres�re nagy�tjuk �s eltoljuk
	w = glm::translate<float>(5, 10, 0) * glm::scale<float>(2, 2, 2);
	DrawSuzanne(w);

	// ************************
	// A F�NYKARDOT MOZGAT� TRANSZFORM�CI�
	// �s a peng�n l�v� f�nyforr�sok poz�ci�i
	// ************************

	// kisz�moljuk azt a transzform�ci�t, ami majd a f�nykardot (�s a fonyforr�sokat) forgatja/mozgatja:
	// el�sz�r -180 �s +180 fokos elforgat�s k�z�tt ing�zik egy szinuszoid szerint, 3 mp-es peri�dussal
	// ezut�n eltoljuk 10 egys�ggel felfel�
	// v�g�l az interakci�val v�ltoztathat� eltol�st alkalmazzuk (ami kezdetben (0,0,0) �rt�k� eltol�s)
	glm::mat4 saber_motion =
		glm::translate<float>(saber_x, saber_y, saber_z) *
		glm::translate<float>(0, 10, 0) *
		glm::rotate<float>(180 * sinf(2 * M_PI * SDL_GetTicks() / 3000.0f), 0, 0, 1);

	// a f�nykardunk peng�j�t alkot� henger "�ll� helyzetben" a (0, 0, 0) pontt�l a (0, 8, 0) pontig terjed
	// (l�sd valamivel lejjebb, a penge l�trehoz�s�n�l)
	// defini�lunk 3 darab pontszer� f�nyforr�st a penge alj�n, k�zep�n �s tetej�n
	// a f�nyforr�sok poz�ci�ja viszont pontosan �gy mozog, ahogy a f�nykardot mozgatjuk, �gy a kezdeti
	// poz�ci�kra alkalmazzuk a fenti �sszetett transzform�ci�t
	glm::vec4 L1_pos = saber_motion * glm::vec4(0, 0, 0, 1);
	glm::vec4 L2_pos = saber_motion * glm::vec4(0, 4, 0, 1);
	glm::vec4 L3_pos = saber_motion * glm::vec4(0, 8, 0, 1);
	m_program.SetUniform("lightPos_saber1", L1_pos.x, L1_pos.y, L1_pos.z);
	m_program.SetUniform("lightPos_saber2", L2_pos.x, L2_pos.y, L2_pos.z);
	m_program.SetUniform("lightPos_saber3", L3_pos.x, L3_pos.y, L3_pos.z);

	// ************************
	// A MARKOLAT
	// ************************

	// el�sz�r m�retre igaz�tjuk (scale ut�n egy 0.2 sugar�, 2 magas henger lesz)
	// ut�na eltoljuk a hely�re �gy, hogy a markolat teteje �ppen a (0,0,0) pontban legyen (translate: 1 egys�ggel lejjebb kell tolnunk)
	// v�g�l alkalmazzuk r� a f�nykardot mozgat� �sszetett transzform�ci�t (saber_motion)
	w = 
		saber_motion *
		glm::translate<float>(0, -1, 0) *
		glm::scale<float>(0.2f, 2, 0.2f);
	glm::vec4 color = glm::vec4(1, 1, 1, 1);
	// diff�z komponensben teljesen feh�r, �s szeretn�nk text�r�zni
	DrawCylinder(w, color, true);
	
	// ************************
	// A PENGE BELS� R�SZE
	// ************************

	// el�sz�r m�retre igaz�tjuk (scale ut�n egy 0.2 sugar�, 8 magas henger lesz)
	// ut�na eltoljuk a hely�re �gy, hogy a penge alja �ppen a (0,0,0) pontban legyen (translate: 4 egys�ggel feljebb kell tolnunk)
	// vagyis a penge a (0,0,0) pontt�l a (0,8,0) pontig h�z�dik
	// v�g�l alkalmazzuk r� a f�nykardot mozgat� �sszetett transzform�ci�t (saber_motion)
	w = 
		saber_motion *
		glm::translate<float>(0, 4, 0) *
		glm::scale<float>(0.2f, 8, 0.2f);
	color = glm::vec4(0.8f, 0.8f, 0.8f, 1);
	// diff�z komponensben kicsit s�t�tebb feh�r, �s nem szeretn�nk text�r�zni
	DrawCylinder(w, color, false);

	// ************************
	// A PENGE K�LS� (�TL�TSZ�) R�SZE
	// ************************

	// mivel �tl�tsz�v� szeretn�nk tenni, be kell kapcsolni a h�tlapokat (ugyanis �t�tsz� objektumoknak l�tjuk a h�tlapjait!)
	glDisable(GL_CULL_FACE);
	// a GL_BLEND bekapcsol�s�val �rtes�tj�k az openGL-t, hogy haszn�lja az alpha (�tl�tszatlans�g) sz�ncsatorn�t...
	glEnable(GL_BLEND);
	// ...ilyen "sz�nkever�si" be�ll�t�ssal - vagyis hogyan keverje ki k�t fregmens sz�n�b�l az eredm�nyt, ha az egyik fregmens �tl�tsz�
	glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

		// A hengert hasonl� transzform�ci�val �p�tj�k fel, mint a penge bels� r�sz�t,
		// de itt a sug�r folyamatosan v�ltozik:
		// 0.21 �s 0.35 k�z�tt ing�zik, 100 millisec peri�dussal
		// a magass�ga 8.01 egys�g
		// (a bels� henger 0.2 sugar� �s 8 egys�g magas, ez�rt ezt a hengert picit nagyobbra �ll�tjuk, hogy
		// ne l�gjanak egym�sba, ami cs�nya effekthez vezetne)
		float vibration_radius = TransformSine(2*f_PI*SDL_GetTicks() / 100.0f, 0.21f, 0.35f);
		w = 
			saber_motion *
			glm::translate<float>(0, 4, 0) *
			glm::scale<float>(vibration_radius, 8.01f, vibration_radius);

		// a diff�z f�ny alpha csatorn�j�t 0.2 �s 0.7 k�z�tt ing�ztatjuk, ugyanolyan peri�dussal, mint a henger sugar�t
		// teh�t amikor a penge a legkisebb (0.21 sug�r), akkor az �tl�tszatlans�g 0.7
		// amikor a penge a legnagyobbra t�gul (0.35 sug�r), akkor a leg�tl�tsz�bb: 0.2
		float vibration_transparency = TransformSine(2*f_PI*SDL_GetTicks() / 100.0f, 0.7f, 0.2f);
		// a dif�z f�ny k�kes, viszont az �tl�tsz�s�got vari�ljuk
		color = glm::vec4(0.2f, 0.5f, 1, vibration_transparency);
		// w transzform�ci�val, color diff�z sz�nnel, text�ra n�lk�l
		DrawCylinder(w, color, false);
	
	// az �tl�tsz� objektum kirajzol�sa ut�n ne felejts�k el ezeket vissza�ll�tani! 
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);

	m_program.Off();

}

void CMyApp::KeyboardDown(SDL_KeyboardEvent& key)
{
	m_camera.KeyboardDown(key);

	switch (key.keysym.sym){
	case SDLK_LEFT:
		saber_x -= 0.5f;
		break;
	case SDLK_RIGHT:
		saber_x += 0.5f;
		break;
	case SDLK_UP:
		saber_y += 0.5f;
		break;
	case SDLK_DOWN:
		saber_y -= 0.5f;
		break;
	case SDLK_r:
		saber_z -= 0.5f;
		break;
	case SDLK_f:
		saber_z += 0.5;
		break;
	}
}

void CMyApp::KeyboardUp(SDL_KeyboardEvent& key)
{
	m_camera.KeyboardUp(key);
}

void CMyApp::MouseMove(SDL_MouseMotionEvent& mouse)
{
	m_camera.MouseMove(mouse);
}

void CMyApp::MouseDown(SDL_MouseButtonEvent& mouse)
{
}

void CMyApp::MouseUp(SDL_MouseButtonEvent& mouse)
{
}

void CMyApp::MouseWheel(SDL_MouseWheelEvent& wheel)
{
}

// a k�t param�terbe az �j ablakm�ret sz�less�ge (_w) �s magass�ga (_h) tal�lhat�
void CMyApp::Resize(int _w, int _h)
{
	glViewport(0, 0, _w, _h);

	m_camera.Resize(_w, _h);
}